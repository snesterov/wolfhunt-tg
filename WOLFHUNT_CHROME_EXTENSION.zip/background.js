// ============================================================================
// WolfHunt PRO 2.0 — Background Service Worker (Manifest V3)
// 24/7 Autonomous Background Hunter for VK & Telegram
// ============================================================================

const MSK_OFFSET_HOURS = 3;
const VK_API_VERSION = "5.131";

function getMskNow() {
  const d = new Date();
  const utc = d.getTime() + (d.getTimezoneOffset() * 60000);
  return new Date(utc + (3600000 * MSK_OFFSET_HOURS));
}

function getTodayStr() {
  const m = getMskNow();
  return `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, '0')}-${String(m.getDate()).padStart(2, '0')}`;
}

// Log utility
async function logMsg(text, type = "info", platform = "vk") {
  const m = getMskNow();
  const timeStr = `${String(m.getHours()).padStart(2, '0')}:${String(m.getMinutes()).padStart(2, '0')}:${String(m.getSeconds()).padStart(2, '0')}`;
  const entry = { time: timeStr, text: text, type: type };
  
  const key = platform === 'tg' ? 'wh_tg_logs' : 'wh_vk_logs';
  const data = await chrome.storage.local.get([key]);
  let logs = data[key] || [];
  logs.push(entry);
  if (logs.length > 50) logs.shift();
  await chrome.storage.local.set({ [key]: logs });
}

// Spintax parser
function parseSpintax(text, firstName = "друг") {
  text = (text || "").replace(/%first_name%/g, firstName || "друг");
  let safety = 10;
  while (text.includes("{") && text.includes("}") && safety-- > 0) {
    text = text.replace(/\{([^{}]+)\}/g, (_, s) => {
      const parts = s.split("|");
      return parts[Math.floor(Math.random() * parts.length)].trim();
    });
  }
  return text;
}

// Call VK API via direct fetch from user's IP (Extension background has full host_permissions!)
async function callVkApi(method, params = {}) {
  const s = await chrome.storage.local.get(['wh_token']);
  const token = params.access_token || s.wh_token;
  if (!token) return null;

  if (s.wh_vk_flood_until && Date.now() < s.wh_vk_flood_until) {
    return { error: { error_code: 9, error_msg: "Flood control active" } };
  }

  params.v = VK_API_VERSION;
  params.access_token = token;

  const url = `https://api.vk.com/method/${method}`;
  const body = new URLSearchParams();
  for (const k in params) body.append(k, params[k]);

  try {
    const res = await fetch(url, {
      method: 'POST',
      body: body
    });
    const data = await res.json();
    if (data && data.error && (data.error.error_code === 9 || (data.error.error_msg && data.error.error_msg.includes('Flood')))) {
      const waitTime = Date.now() + 180000; // 3 min pause
      await chrome.storage.local.set({ wh_vk_flood_until: waitTime });
      await logMsg("⏳ [VK Защита] Flood control: ВК запросил паузу 3 мин. Охота не сбивается, возобновится автоматически.", "warn", "vk");
    }
    return data;
  } catch (err) {
    console.error(`[VK API Error] ${method}:`, err);
    return { error: { error_msg: err.message, error_code: -1 } };
  }
}

// ----------------------------------------------------------------------------
// VK 3-TACT HUNTER ENGINE
// ----------------------------------------------------------------------------
async function huntStories() {
  await logMsg("👁 [Фаза: Истории] Поиск свежих историй друзей...", "info", "vk");
  const res = await callVkApi("stories.get", { extended: "1" });
  if (!res || !res.response || !res.response.items || res.response.items.length === 0) {
    return false;
  }

  const items = res.response.items;
  const profiles = {};
  (res.response.profiles || []).forEach(p => { profiles[p.id] = p; });

  const s = await chrome.storage.local.get(['wh_seen_stories', 'wh_story_likes', 'wh_today_likes', 'wh_all_time_stories', 'wh_all_time_total']);
  let seen = s.wh_seen_stories || [];

  for (const author of items) {
    const ownerId = author.id || author.owner_id;
    const storiesList = author.stories || [];
    if (!storiesList.length) continue;

    const freshStory = storiesList[storiesList.length - 1];
    const storyId = freshStory.id;
    const seenKey = `${ownerId}_${storyId}`;
    if (seen.includes(seenKey)) continue;

    const prof = profiles[ownerId] || {};
    const name = `${prof.first_name || ''} ${prof.last_name || ''}`.trim() || `id${ownerId}`;

    // Send Reaction
    await callVkApi("stories.sendInteraction", {
      owner_id: String(ownerId),
      story_id: String(storyId),
      message: "❤"
    });

    seen.push(seenKey);
    if (seen.length > 500) seen.shift();

    const stCount = (parseInt(s.wh_story_likes) || 0) + 1;
    const allStCount = (parseInt(s.wh_all_time_stories) || 0) + 1;
    const todayLikes = (parseInt(s.wh_today_likes) || 0) + 1;
    const allTotal = (parseInt(s.wh_all_time_total) || 0) + 1;
    await chrome.storage.local.set({
      wh_seen_stories: seen,
      wh_story_likes: stCount.toString(),
      wh_all_time_stories: allStCount.toString(),
      wh_today_likes: todayLikes.toString(),
      wh_all_time_total: allTotal.toString()
    });

    await logMsg(`🔥 [Истории] Охота: ${name} ❤`, "success", "vk");
    return true;
  }
  return false;
}

async function checkBirthdaysDaily() {
  const s = await chrome.storage.local.get([
    'wh_bday_enable', 'wh_bday_text', 'wh_bday_cache_date', 'wh_bday_cache',
    'wh_bday_congratulated', 'wh_bday_count'
  ]);

  if (s.wh_bday_enable === '0') return false;

  const msk = getMskNow();
  const hour = msk.getHours();
  // Strictly between 06:00 and 22:00 MSK
  if (hour < 6 || hour > 22) return false;

  const curDM = `${msk.getDate()}.${msk.getMonth() + 1}`;
  const curY = String(msk.getFullYear());
  const todayStr = getTodayStr();

  // 1. Fetch once per 24h
  let bdays = s.wh_bday_cache || [];
  if (s.wh_bday_cache_date !== todayStr) {
    const res = await callVkApi("friends.get", { fields: "bdate,first_name,can_write_private_message" });
    bdays = [];
    if (res && res.response && res.response.items) {
      for (const f of res.response.items) {
        if (!f.bdate) continue;
        const p = f.bdate.split(".");
        if (p.length >= 2 && `${parseInt(p[0])}.${parseInt(p[1])}` === curDM) {
          bdays.push({ id: f.id, name: f.first_name || 'друг', can_msg: f.can_write_private_message !== 0 });
        }
      }
    }
    await chrome.storage.local.set({ wh_bday_cache: bdays, wh_bday_cache_date: todayStr });
    if (bdays.length > 0) {
      await logMsg(`🎂 [День Рождения] База на сегодня сформирована: ${bdays.length} именинников. Отправка пачками до 5 в Такте №2.`, "info", "vk");
    } else {
      await logMsg(`🎂 [День Рождения] База на сегодня проверена: именинников среди друзей нет.`, "info", "vk");
    }
  }

  if (!bdays.length) return false;

  const congratulated = s.wh_bday_congratulated || [];
  const bText = s.wh_bday_text || "{С днем рождения|С праздником}, %first_name%! {Всего самого наилучшего}! 🎂";

  // 2. Filter un-congratulated today
  const pending = bdays.filter(f => !congratulated.includes(`${curY}_${f.id}`));
  if (!pending.length) {
    return false; // Queue exhausted for today
  }

  // 3. Batch up to 5 per tact
  const batch = pending.slice(0, 5);
  await logMsg(`🎂 [Такт 2/3: День Рождения] Отправка партии (${batch.length} из ${pending.length} в очереди)...`, "info", "vk");

  let sentBatchCount = 0;
  let bCnt = parseInt(s.wh_bday_count) || 0;

  for (let i = 0; i < batch.length; i++) {
    const f = batch[i];
    const bKey = `${curY}_${f.id}`;
    if (!f.can_msg) {
      congratulated.push(bKey);
      continue;
    }

    try {
      const msg = parseSpintax(bText, f.name);
      await callVkApi("messages.send", {
        user_id: String(f.id),
        message: msg,
        random_id: Math.floor(Math.random() * 100000000).toString()
      });
      congratulated.push(bKey);
      bCnt++;
      sentBatchCount++;
      await logMsg(`🎂 [Поздравление ${sentBatchCount}/${batch.length}]: ${f.name} (${msg.slice(0, 30)}...)`, "success", "vk");
    } catch (e) {
      await logMsg(`⚠️ Ошибка поздравления ${f.name}: ${e.message}`, "warn", "vk");
      congratulated.push(bKey);
    }

    // Soft human delay between messages in the batch (3-5 sec)
    if (i < batch.length - 1) {
      await sleep(3500 + Math.random() * 1500);
    }
  }

  const allBdays = (parseInt(s.wh_all_time_bdays || '0') + sentBatchCount).toString();
  await chrome.storage.local.set({
    wh_bday_congratulated: congratulated,
    wh_bday_count: bCnt.toString(),
    wh_all_time_bdays: allBdays
  });

  const remaining = pending.length - batch.length;
  if (remaining > 0) {
    await logMsg(`🎂 [Такт 2/3: Партия завершена] Отправлено: ${sentBatchCount}. Осталось в очереди на следующие такты: ${remaining}.`, "info", "vk");
  } else {
    await logMsg(`🎂 [Такт 2/3: Именинники закрыты] Все поздравления на сегодня отправлены (${sentBatchCount})! ✅`, "success", "vk");
  }

  return true;
}

async function huntPosts() {
  await logMsg("🔍 [Фаза: Посты] Поиск свежих записей друзей...", "info", "vk");
  const res = await callVkApi("newsfeed.get", { filters: "post", count: "15" });
  if (!res || !res.response || !res.response.items) return false;

  const items = res.response.items;
  const s = await chrome.storage.local.get(['wh_seen_posts', 'wh_post_likes', 'wh_today_likes', 'wh_all_time_posts', 'wh_all_time_total']);
  let seen = s.wh_seen_posts || [];

  for (const p of items) {
    const ownerId = p.source_id || p.owner_id;
    const postId = p.post_id;
    if (!ownerId || ownerId <= 0 || !postId) continue;

    const pKey = `${ownerId}_${postId}`;
    if (seen.includes(pKey)) continue;

    if (p.likes && p.likes.user_likes === 1) {
      seen.push(pKey);
      continue;
    }

    await callVkApi("likes.add", {
      type: "post",
      owner_id: String(ownerId),
      item_id: String(postId)
    });

    seen.push(pKey);
    if (seen.length > 500) seen.shift();

    const pCount = (parseInt(s.wh_post_likes) || 0) + 1;
    const allPCount = (parseInt(s.wh_all_time_posts) || 0) + 1;
    const todayLikes = (parseInt(s.wh_today_likes) || 0) + 1;
    const allTotal = (parseInt(s.wh_all_time_total) || 0) + 1;
    await chrome.storage.local.set({
      wh_seen_posts: seen,
      wh_post_likes: pCount.toString(),
      wh_all_time_posts: allPCount.toString(),
      wh_today_likes: todayLikes.toString(),
      wh_all_time_total: allTotal.toString()
    });

    await logMsg(`❤ [Посты] Разбавка: Лайк к записи id${ownerId}`, "success", "vk");
    return true;
  }
  return false;
}

// Main 3-tact loop step
async function executeVkHuntingStep() {
  const s = await chrome.storage.local.get([
    'wh_token', 'wh_running', 'wh_last_date', 'wh_current_phase',
    'wh_today_likes', 'wh_auto_paused_limit', 'wh_vk_flood_until'
  ]);

  if (s.wh_running !== 'true' || !s.wh_token) return;

  // Check VK flood timer
  if (s.wh_vk_flood_until && Date.now() < s.wh_vk_flood_until) return;

  // Day rollover at 00:00 MSK
  const today = getTodayStr();
  if (s.wh_last_date !== today) {
    await chrome.storage.local.set({
      wh_last_date: today,
      wh_story_likes: '0',
      wh_post_likes: '0',
      wh_today_likes: '0',
      wh_auto_paused_limit: 'false',
      wh_bday_cache_date: '',
      wh_bday_cache: []
    });
    await logMsg("🚀 Новый день (00:00 МСК)! Счетчики сброшены, охота 24/7 активна ✅", "success", "vk");
  }

  // Check 300 daily limit
  const todayLikes = parseInt(s.wh_today_likes || '0');
  if (todayLikes >= 300) {
    if (s.wh_auto_paused_limit !== 'true') {
      await chrome.storage.local.set({ wh_auto_paused_limit: 'true' });
      await logMsg(`🛑 [Суточный лимит 300] Пауза на ночь (${todayLikes} лайков). Автостарт в 00:00 МСК! 🌙`, "warn", "vk");
    }
    return;
  }

  // 3-Tact Strict Cycle
  let phase = parseInt(s.wh_current_phase || '0');
  await chrome.storage.local.set({ wh_current_phase: ((phase + 1) % 3).toString() });

  try {
    if (phase === 0) {
      await logMsg("🎯 [Такт 1/3: Истории] Охота на истории (Приоритет №1)...", "info", "vk");
      await huntStories();
    } else if (phase === 1) {
      const done = await checkBirthdaysDaily();
      if (!done) {
        await logMsg("👁 [Такт 2/3: Истории] Очередь именинников на сегодня пуста. Охота на истории (Приоритет №1)...", "info", "vk");
        await huntStories();
      }
    } else {
      await logMsg("📰 [Такт 3/3: Посты] Разбавка ленты постом...", "info", "vk");
      await huntPosts();
    }
  } catch (err) {
    await logMsg(`Ошибка цикла: ${err.message}`, "error", "vk");
  }
}

// ----------------------------------------------------------------------------
// CLOUD SAAS SYNCHRONIZATION (app.greyzzzzwolf.ru ⟷ Chrome Extension)
// ----------------------------------------------------------------------------
const CLOUD_SYNC_URL = "https://wolfhunt-tg.onrender.com/api/vk/sync";

async function syncVkWithCloud(forcePushSettings = false) {
  try {
    const s = await chrome.storage.local.get([
      'wh_token', 'wh_user_id', 'wh_name', 'wh_nick', 'wh_running',
      'wh_story_likes', 'wh_post_likes', 'wh_bday_count', 'wh_all_time_stories', 'wh_all_time_posts', 'wh_all_time_bdays', 'wh_all_time_total',
      'wh_bday_text', 'wh_bday_enable', 'wh_vk_logs'
    ]);
    if (!s.wh_token || !s.wh_user_id) return;

    const payload = {
      user_id: String(s.wh_user_id),
      token: s.wh_token,
      name: s.wh_name || `id${s.wh_user_id}`,
      nick: s.wh_nick || `id${s.wh_user_id}`,
      running: s.wh_running === 'true',
      today_stories: parseInt(s.wh_story_likes || '0'),
      today_posts: parseInt(s.wh_post_likes || '0'),
      bday_count: parseInt(s.wh_bday_count || '0'),
      all_time_stories: parseInt(s.wh_all_time_stories || '0'),
      all_time_posts: parseInt(s.wh_all_time_posts || '0'),
      all_time_bdays: parseInt(s.wh_all_time_bdays || '0'),
      all_time_total: parseInt(s.wh_all_time_total || '0'),
      logs: s.wh_vk_logs || [],
      extension_version: (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : "2.0.3"
    };

    if (forcePushSettings) {
      if (s.wh_bday_text) payload.bday_text_update = s.wh_bday_text;
      payload.bday_enabled_update = s.wh_bday_enable !== '0';
    }

    const res = await fetch(CLOUD_SYNC_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) return;
    const data = await res.json();
            if (data.status === 'ok') {
      const up = {};
      if (data.all_time_stories && data.all_time_stories > parseInt(s.wh_all_time_stories || '0')) up.wh_all_time_stories = data.all_time_stories.toString();
      if (data.all_time_posts && data.all_time_posts > parseInt(s.wh_all_time_posts || '0')) up.wh_all_time_posts = data.all_time_posts.toString();
      if (data.all_time_bdays && data.all_time_bdays > parseInt(s.wh_all_time_bdays || '0')) up.wh_all_time_bdays = data.all_time_bdays.toString();
      if (data.all_time_total && data.all_time_total > parseInt(s.wh_all_time_total || '0')) up.wh_all_time_total = data.all_time_total.toString();
      if (Object.keys(up).length > 0) await chrome.storage.local.set(up);
      if (data.has_update) {
        await chrome.storage.local.set({
          wh_has_update: 'true',
          wh_latest_ver: data.latest_extension_version || '2.0.3',
          wh_update_title: data.update_title || 'Доступно обновление!',
          wh_update_desc: data.update_desc || 'Скачайте свежую версию расширения.',
          wh_update_url: data.update_url || CLOUD_SYNC_URL
        });
        if (chrome.action && chrome.action.setBadgeText) {
          chrome.action.setBadgeText({ text: 'NEW' });
          chrome.action.setBadgeBackgroundColor({ color: '#f43f5e' });
        }
      } else {
        await chrome.storage.local.set({ wh_has_update: 'false' });
        if (chrome.action && chrome.action.setBadgeText) {
          chrome.action.setBadgeText({ text: '' });
        }
      }
      // 1. SYNC RUNNING STATE (Stop signal from website only; never auto-start unexpectedly)
      if (data.is_running !== undefined) {
        const cloudRun = data.is_running ? 'true' : 'false';
        if (cloudRun === 'false' && s.wh_running === 'true') {
          await chrome.storage.local.set({ wh_running: 'false' });
          await logMsg("⏸ [Сигнал с сайта] Охота ВК приостановлена по команде с сайта!", "warn", "vk");
        }
      }

      // 2. SYNC BDAY SETTINGS
      if (!forcePushSettings && data.bday_text && data.bday_text !== s.wh_bday_text) {
        await chrome.storage.local.set({
          wh_bday_text: data.bday_text,
          wh_bday_enable: data.bday_enabled ? '1' : '0'
        });
      }
    }
  } catch (err) {
    // Soft network catch
  }
}

// Fast cloud poller for instant stop/start command synchronization (every 6 sec)
setInterval(() => {
  syncVkWithCloud(false);
}, 6000);

// ----------------------------------------------------------------------------
// ALARMS & BACKGROUND SCHEDULING (Manifest V3 24/7)
// ----------------------------------------------------------------------------
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "wolfhunt_tick") {
    await executeVkHuntingStep();
    await syncVkWithCloud(false);
  }
});

// Setup alarm on extension install/start
chrome.runtime.onStartup.addListener(async () => {
  await chrome.storage.local.set({ wh_running: 'false' });
});

chrome.runtime.onInstalled.addListener(async () => {
  chrome.alarms.create("wolfhunt_tick", { periodInMinutes: 0.5 });
  await chrome.storage.local.set({ wh_running: 'false' });
  console.log("WolfHunt PRO Extension background worker installed (paused by default).");
});

// Internal active timer loop while service worker is awake
let isLoopRunning = false;
async function continuousBackgroundLoop() {
  if (isLoopRunning) return;
  isLoopRunning = true;
  while (true) {
    await executeVkHuntingStep();
    await syncVkWithCloud(false);
    const delay = Math.floor(Math.random() * (45 - 25 + 1) + 25) * 1000;
    await new Promise(r => setTimeout(r, delay));
  }
}
continuousBackgroundLoop();

// Message listener for popup actions
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.action === "hunt_vk_now") {
    executeVkHuntingStep().then(() => sendResponse({ status: "ok" }));
    return true;
  }
  if (req.action === "sync_cloud") {
    syncVkWithCloud(req.forcePushSettings || false).then(() => sendResponse({ status: "ok" }));
    return true;
  }
  if (req.action === "get_status") {
    chrome.storage.local.get(null).then(data => sendResponse(data));
    return true;
  }
});
