/**
 * 🐺 WOLFHUNT PRO v2.1.0 — CHROME EXTENSION BACKGROUND SERVICE WORKER
 * Единый облачный спутник для управления и мониторинга 24/7 сервера Render.
 * Все действия ВКонтакте выполняются СТРОГО на сервере Render, исключая риск бана и конфликтов IP.
 */

const CLOUD_BASE_URL = "https://wolfhunt-tg.onrender.com";

async function logMsg(text, type = "info") {
  const timeStr = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const s = await chrome.storage.local.get(['wh_vk_logs']);
  const logs = s.wh_vk_logs || [];
  logs.push({ time: timeStr, text: text, type: type });
  if (logs.length > 60) logs.shift();
  await chrome.storage.local.set({ wh_vk_logs: logs });
}

async function syncWithCloud() {
  try {
    const s = await chrome.storage.local.get(['wh_token']);
    const res = await fetch(`${CLOUD_BASE_URL}/api/vk/status`, {
      headers: { 'Cache-Control': 'no-cache' }
    });
    if (!res.ok) return;
    const data = await res.json();

    if (data.status === "ok") {
      const updates = {
        wh_running: data.is_running ? 'true' : 'false',
        wh_user_id: data.user_id ? String(data.user_id) : '',
        wh_name: data.name || 'Сергей Нестеров',
        wh_nick: data.screen_name || '',
        wh_today_likes: String(data.today_total || 0),
        wh_story_likes: String(data.today_stories || 0),
        wh_post_likes: String(data.today_posts || 0),
        wh_all_time_stories: String(data.all_time_stories || 0),
        wh_all_time_posts: String(data.all_time_posts || 0),
        wh_all_time_total: String(data.all_time_total || 0)
      };

      if (data.logs && Array.isArray(data.logs)) {
        updates.wh_vk_logs = data.logs;
      }

      await chrome.storage.local.set(updates);

      // Обновление бейджа на иконке расширения
      if (chrome.action && chrome.action.setBadgeText) {
        if (data.is_running) {
          chrome.action.setBadgeText({ text: 'ON' });
          chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
        } else {
          chrome.action.setBadgeText({ text: '' });
        }
      }
    }
  } catch (err) {
    // Тихо игнорируем секундные сбои сети
  }
}

// Периодический опрос сервера раз в 10 секунд
setInterval(syncWithCloud, 10000);

chrome.runtime.onStartup.addListener(() => {
  syncWithCloud();
});

chrome.runtime.onInstalled.addListener(() => {
  syncWithCloud();
  console.log("🐺 WolfHunt PRO v2.1.0 Cloud Companion установлен.");
});

// Слушатель сообщений от popup окна
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.action === "toggle_vk") {
    fetch(`${CLOUD_BASE_URL}/api/vk/toggle`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: req.subAction || "toggle" })
    })
    .then(r => r.json())
    .then(data => {
      syncWithCloud();
      sendResponse(data);
    })
    .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (req.action === "hunt_vk_now") {
    fetch(`${CLOUD_BASE_URL}/api/vk/like_once`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    })
    .then(r => r.json())
    .then(data => {
      syncWithCloud();
      sendResponse(data);
    })
    .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (req.action === "auth_vk") {
    fetch(`${CLOUD_BASE_URL}/api/vk/auth`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: req.token })
    })
    .then(r => r.json())
    .then(data => {
      if (data.status === "ok") {
        chrome.storage.local.set({
          wh_token: req.token,
          wh_user_id: String(data.user_id),
          wh_name: data.name,
          wh_nick: data.screen_name,
          wh_running: 'true'
        });
      }
      syncWithCloud();
      sendResponse(data);
    })
    .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (req.action === "logout_vk") {
    fetch(`${CLOUD_BASE_URL}/api/vk/logout`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    })
    .then(r => r.json())
    .then(data => {
      chrome.storage.local.remove(['wh_token', 'wh_name', 'wh_nick', 'wh_user_id', 'wh_running']);
      syncWithCloud();
      sendResponse(data);
    })
    .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (req.action === "sync_cloud") {
    syncWithCloud().then(() => sendResponse({ status: "ok" }));
    return true;
  }
});
