/**
 * 🐺 WOLFHUNT PRO v2.1.0 — POPUP CONTROLLER
 * Управление 24/7 облачным сервисом Render.
 */

const CLOUD_URL = "https://wolfhunt-tg.onrender.com";
const $ = (id) => document.getElementById(id);

document.addEventListener("DOMContentLoaded", async () => {
  initTabs();
  initFaq();
  initVkControls();
  initTgControls();
  await refreshVkUi();
  await refreshTgUi();

  // Автообновление UI раз в 4 секунды при открытом popup
  setInterval(async () => {
    await refreshVkUi();
    await refreshTgUi();
  }, 4000);
});

// ----------------------------------------------------------------------------
// 1. НАВИГАЦИЯ И FAQ
// ----------------------------------------------------------------------------
function initTabs() {
  const tabVk = $("wh-tab-vk");
  const tabTg = $("wh-tab-tg");
  const viewVk = $("wh-view-vk");
  const viewTg = $("wh-view-tg");

  if (tabVk && tabTg) {
    tabVk.onclick = () => {
      viewVk.style.display = "block";
      viewTg.style.display = "none";
      tabVk.style.background = "linear-gradient(135deg,#0077ff,#0055cc)";
      tabVk.style.color = "#fff";
      tabVk.style.boxShadow = "0 4px 14px rgba(0,119,255,0.4)";
      tabTg.style.background = "transparent";
      tabTg.style.color = "#94a3b8";
      tabTg.style.boxShadow = "none";
    };

    tabTg.onclick = () => {
      viewVk.style.display = "none";
      viewTg.style.display = "block";
      tabTg.style.background = "linear-gradient(135deg,#0284c7,#0369a1)";
      tabTg.style.color = "#fff";
      tabTg.style.boxShadow = "0 4px 14px rgba(2,132,199,0.4)";
      tabVk.style.background = "transparent";
      tabVk.style.color = "#94a3b8";
      tabVk.style.boxShadow = "none";
      refreshTgUi();
    };
  }
}

function initFaq() {
  const toggle = $("wh-vk-faq-toggle");
  const content = $("wh-vk-faq-content");
  const arrow = $("wh-vk-faq-arrow");
  if (toggle && content) {
    toggle.onclick = () => {
      const isHidden = content.style.display === "none";
      content.style.display = isHidden ? "block" : "none";
      if (arrow) arrow.innerText = isHidden ? "Свернуть ▴" : "Развернуть ▾";
    };
  }
}

// ----------------------------------------------------------------------------
// 2. ВКОНТАКТЕ УПРАВЛЕНИЕ И UI
// ----------------------------------------------------------------------------
async function refreshVkUi() {
  const s = await chrome.storage.local.get([
    "wh_token", "wh_name", "wh_nick", "wh_running",
    "wh_story_likes", "wh_post_likes", "wh_today_likes", "wh_all_time_total",
    "wh_vk_logs"
  ]);

  const hasToken = !!s.wh_token;
  const isRunning = s.wh_running === "true";

  // Карточка авторизации
  if ($("wh-auth-card")) $("wh-auth-card").style.display = hasToken ? "none" : "block";
  if ($("wh-reset-btn")) $("wh-reset-btn").style.display = hasToken ? "inline-flex" : "none";

  // Профиль
  if ($("wh-name")) $("wh-name").innerText = s.wh_name || (hasToken ? "Сергей Нестеров" : "Требуется вход");
  if ($("wh-nick")) $("wh-nick").innerText = s.wh_nick ? `@${s.wh_nick}` : (hasToken ? "id49239823" : "");
  if ($("wh-sub")) {
    if (!hasToken) {
      $("wh-sub").innerText = "⏸ Аккаунт не подключен";
      $("wh-sub").style.color = "#94a3b8";
    } else if (isRunning) {
      $("wh-sub").innerText = "🟢 Охота активна 24/7 (Приоритет: Истории)";
      $("wh-sub").style.color = "#34d399";
    } else {
      $("wh-sub").innerText = "⏸ На паузе";
      $("wh-sub").style.color = "#f59e0b";
    }
  }

  // Кнопка Старт / Пауза
  const toggleBtn = $("wh-toggle-btn");
  if (toggleBtn) {
    if (isRunning) {
      toggleBtn.innerText = "⏸ Приостановить";
      toggleBtn.style.background = "linear-gradient(135deg,#f43f5e,#be123c)";
    } else {
      toggleBtn.innerText = "🚀 Запустить охоту 24/7";
      toggleBtn.style.background = "linear-gradient(135deg,#10b981,#059669)";
    }
  }

  // Счетчики
  if ($("wh-stories")) $("wh-stories").innerText = s.wh_story_likes || "0";
  if ($("wh-post-likes")) $("wh-post-likes").innerText = s.wh_post_likes || "0";
  if ($("wh-today-likes")) $("wh-today-likes").innerText = `${s.wh_today_likes || 0} / 300`;
  if ($("wh-all-time-total")) $("wh-all-time-total").innerText = s.wh_all_time_total || "0";

  // Логи
  renderLogs("wh-log-stream", s.wh_vk_logs || []);
}

function initVkControls() {
  // Кнопка Сохранить токен
  const saveBtn = $("wh-save-btn");
  if (saveBtn) {
    saveBtn.onclick = async () => {
      const raw = ($("wh-token-raw") ? $("wh-token-raw").value : "").trim();
      const msg = $("wh-msg");
      if (!raw) {
        if (msg) { msg.innerText = "⚠️ Вставьте токен или ссылку!"; msg.style.color = "#f87171"; }
        return;
      }

      let token = raw;
      if (token.includes("access_token=")) {
        const m = token.match(/access_token=([^&]+)/);
        if (m) token = m[1];
      }

      saveBtn.disabled = true;
      if (msg) { msg.innerText = "⏳ Подключение к 24/7 облаку..."; msg.style.color = "#38bdf8"; }

      chrome.runtime.sendMessage({ action: "auth_vk", token: token }, async (res) => {
        saveBtn.disabled = false;
        if (res && res.status === "ok") {
          if (msg) { msg.innerText = "✔ Успешно подключено к облаку Render!"; msg.style.color = "#34d399"; }
          if ($("wh-token-raw")) $("wh-token-raw").value = "";
          await refreshVkUi();
        } else {
          if (msg) { msg.innerText = `❌ Ошибка: ${res?.error || "Неверный токен"}`; msg.style.color = "#f87171"; }
        }
      });
    };
  }

  // Кнопка Переключить охоту (Старт / Стоп)
  const toggleBtn = $("wh-toggle-btn");
  if (toggleBtn) {
    toggleBtn.onclick = () => {
      toggleBtn.disabled = true;
      chrome.runtime.sendMessage({ action: "toggle_vk" }, () => {
        toggleBtn.disabled = false;
        refreshVkUi();
      });
    };
  }

  // Кнопка Сменить аккаунт
  const resetBtn = $("wh-reset-btn");
  if (resetBtn) {
    resetBtn.onclick = () => {
      if (confirm("Отключить профиль ВКонтакте?")) {
        chrome.runtime.sendMessage({ action: "logout_vk" }, () => {
          refreshVkUi();
        });
      }
    };
  }

  // Кнопка Тестовый разовый лайк
  const nowBtn = $("wh-btn-now");
  if (nowBtn) {
    nowBtn.onclick = () => {
      nowBtn.disabled = true;
      nowBtn.innerText = "⏳ Лайкаем...";
      chrome.runtime.sendMessage({ action: "hunt_vk_now" }, (res) => {
        nowBtn.disabled = false;
        nowBtn.innerText = "⚡ Тестовый лайк";
        refreshVkUi();
      });
    };
  }

  // Кнопка Копировать лог
  const copyBtn = $("wh-btn-vk-copy-log");
  if (copyBtn) {
    copyBtn.onclick = async () => {
      const s = await chrome.storage.local.get(["wh_vk_logs"]);
      const logs = (s.wh_vk_logs || []).map(l => `[${l.time}] ${l.text}`).join("\n");
      navigator.clipboard.writeText(logs);
      copyBtn.innerText = "✔ Скопировано";
      setTimeout(() => { copyBtn.innerText = "📋 Лог"; }, 1500);
    };
  }
}

// ----------------------------------------------------------------------------
// 3. TELEGRAM УПРАВЛЕНИЕ И UI
// ----------------------------------------------------------------------------
async function refreshTgUi() {
  try {
    const res = await fetch(`${CLOUD_URL}/api/tg/status`);
    if (!res.ok) return;
    const data = await res.json();
    if (data.status !== "ok") return;

    const isAuth = !!data.is_authorized;
    const isRunning = !!data.is_running;
    const user = data.user;

    if ($("wh-tg-auth-card")) $("wh-tg-auth-card").style.display = isAuth ? "none" : "block";
    if ($("wh-tg-reset-btn")) $("wh-tg-reset-btn").style.display = isAuth ? "inline-flex" : "none";
    if ($("wh-tg-dot")) $("wh-tg-dot").style.background = isAuth ? "#10b981" : "#64748b";

    if (isAuth && user) {
      if ($("wh-tg-name")) $("wh-tg-name").innerText = `${user.first_name || ""} ${user.last_name || ""}`.trim() || "Telegram";
      if ($("wh-tg-nick")) $("wh-tg-nick").innerText = user.username ? `@${user.username}` : `id${user.id}`;
    }

    if ($("wh-tg-sub")) {
      if (!isAuth) {
        $("wh-tg-sub").innerText = "⏸ Не авторизован";
        $("wh-tg-sub").style.color = "#94a3b8";
      } else if (isRunning) {
        $("wh-tg-sub").innerText = "🟢 Автоохота 24/7 активна";
        $("wh-tg-sub").style.color = "#10b981";
      } else {
        $("wh-tg-sub").innerText = "⏸ На паузе";
        $("wh-tg-sub").style.color = "#f59e0b";
      }
    }

    const tgToggleBtn = $("wh-tg-toggle-btn");
    if (tgToggleBtn) {
      if (isRunning) {
        tgToggleBtn.innerText = "⏸ Приостановить TG";
        tgToggleBtn.style.background = "linear-gradient(135deg,#f43f5e,#be123c)";
      } else {
        tgToggleBtn.innerText = "🚀 Запустить TG 24/7";
        tgToggleBtn.style.background = "linear-gradient(135deg,#0284c7,#0369a1)";
      }
    }

    if ($("wh-tg-stat-reactions")) $("wh-tg-stat-reactions").innerText = data.reactions_today || "0";
    if ($("wh-tg-stat-views")) $("wh-tg-stat-views").innerText = data.views_today || "0";
    if ($("wh-tg-stat-limit")) $("wh-tg-stat-limit").innerText = `${data.reactions_today || 0} / 150`;
    if ($("wh-tg-stat-all-time")) $("wh-tg-stat-all-time").innerText = data.reactions_all_time || "0";

    renderLogs("wh-tg-log-stream", data.logs || []);
  } catch (err) {}
}

function initTgControls() {
  const btnSend = $("wh-tg-btn-send");
  if (btnSend) {
    btnSend.onclick = async () => {
      const phone = ($("wh-tg-phone-input") ? $("wh-tg-phone-input").value : "").trim();
      const msg = $("wh-tg-auth-msg");
      if (!phone) {
        if (msg) { msg.innerText = "⚠️ Введите номер телефона!"; msg.style.color = "#f87171"; }
        return;
      }
      btnSend.disabled = true;
      if (msg) { msg.innerText = "⏳ Отправка кода в Telegram..."; msg.style.color = "#38bdf8"; }

      try {
        const res = await fetch(`${CLOUD_URL}/api/tg/send_code`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ phone })
        });
        const data = await res.json();
        btnSend.disabled = false;
        if (data.status === "ok") {
          $("wh-tg-step-phone").style.display = "none";
          $("wh-tg-step-code").style.display = "block";
          if (msg) { msg.innerText = "✔ Код отправлен в приложение Telegram!"; msg.style.color = "#34d399"; }
        } else {
          if (msg) { msg.innerText = `❌ ${data.error || "Ошибка"}`; msg.style.color = "#f87171"; }
        }
      } catch (e) {
        btnSend.disabled = false;
        if (msg) { msg.innerText = `❌ Ошибка сети: ${e.message}`; msg.style.color = "#f87171"; }
      }
    };
  }

  const btnVerify = $("wh-tg-btn-verify");
  if (btnVerify) {
    btnVerify.onclick = async () => {
      const code = ($("wh-tg-code-input") ? $("wh-tg-code-input").value : "").trim();
      const pwd = ($("wh-tg-pwd-input") ? $("wh-tg-pwd-input").value : "").trim();
      const msg = $("wh-tg-auth-msg");
      btnVerify.disabled = true;

      try {
        let endpoint = pwd ? "/api/tg/auth_2fa" : "/api/tg/verify_code";
        let payload = pwd ? { password: pwd } : { code: code };
        const res = await fetch(`${CLOUD_URL}${endpoint}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const data = await res.json();
        btnVerify.disabled = false;

        if (data.status === "2fa_required") {
          $("wh-tg-step-pwd").style.display = "block";
          if (msg) { msg.innerText = "🔐 Введите облачный пароль 2FA"; msg.style.color = "#f59e0b"; }
        } else if (data.status === "ok") {
          if (msg) { msg.innerText = "✔ Telegram успешно подключен!"; msg.style.color = "#34d399"; }
          await refreshTgUi();
        } else {
          if (msg) { msg.innerText = `❌ ${data.error || "Неверный код"}`; msg.style.color = "#f87171"; }
        }
      } catch (e) {
        btnVerify.disabled = false;
        if (msg) { msg.innerText = `❌ ${e.message}`; msg.style.color = "#f87171"; }
      }
    };
  }

  const tgToggleBtn = $("wh-tg-toggle-btn");
  if (tgToggleBtn) {
    tgToggleBtn.onclick = async () => {
      tgToggleBtn.disabled = true;
      await fetch(`${CLOUD_URL}/api/tg/toggle`, { method: "POST" });
      tgToggleBtn.disabled = false;
      await refreshTgUi();
    };
  }

  const tgResetBtn = $("wh-tg-reset-btn");
  if (tgResetBtn) {
    tgResetBtn.onclick = async () => {
      if (confirm("Выйти из профиля Telegram?")) {
        await fetch(`${CLOUD_URL}/api/tg/logout`, { method: "POST" });
        await refreshTgUi();
      }
    };
  }

  const tgNowBtn = $("wh-tg-btn-now");
  if (tgNowBtn) {
    tgNowBtn.onclick = async () => {
      tgNowBtn.disabled = true;
      tgNowBtn.innerText = "⏳ Лайкаем...";
      await fetch(`${CLOUD_URL}/api/tg/like_once`, { method: "POST" });
      tgNowBtn.disabled = false;
      tgNowBtn.innerText = "⚡ Тестовый лайк";
      await refreshTgUi();
    };
  }
}

// ----------------------------------------------------------------------------
// РЕНДЕР ЛОГОВ
// ----------------------------------------------------------------------------
function renderLogs(containerId, logs) {
  const container = $(containerId);
  if (!container) return;
  if (!logs || !logs.length) {
    container.innerHTML = "<div>[Система]: Ожидание событий...</div>";
    return;
  }
  container.innerHTML = logs.map(l => {
    let col = "#94a3b8";
    if (l.type === "success") col = "#34d399";
    if (l.type === "warn") col = "#f59e0b";
    if (l.type === "error") col = "#f87171";
    return `<div style="color:${col}; margin-bottom:2px;">[${l.time}] ${l.text}</div>`;
  }).join("");
  container.scrollTop = container.scrollHeight;
}
