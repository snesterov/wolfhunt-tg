// ============================================================================
// WolfHunt PRO 2.0 — Popup Controller (Manifest V3)
// ============================================================================

const $ = (id) => document.getElementById(id);
const TG_API_URL = "https://wolfhunt-tg.onrender.com";

// Tab Switching
function switchTab(tab) {
  const isTg = (tab === 'tg');
  const vkC = $('wh-view-vk'), tgC = $('wh-view-tg'), vkB = $('wh-tab-vk'), tgB = $('wh-tab-tg');
  if (vkC) vkC.style.display = isTg ? 'none' : 'block';
  if (tgC) tgC.style.display = isTg ? 'block' : 'none';
  if (vkB) {
    vkB.style.background = isTg ? 'transparent' : 'linear-gradient(135deg,#0077ff,#0055cc)';
    vkB.style.color = isTg ? '#94a3b8' : '#fff';
    vkB.style.boxShadow = isTg ? 'none' : '0 4px 14px rgba(0,119,255,0.4)';
  }
  if (tgB) {
    tgB.style.background = isTg ? 'linear-gradient(135deg,#0284c7,#0369a1)' : 'transparent';
    tgB.style.color = isTg ? '#fff' : '#94a3b8';
    tgB.style.boxShadow = isTg ? '0 4px 14px rgba(2,132,199,0.4)' : 'none';
  }
  chrome.storage.local.set({ wh_active_tab: tab });
  if (isTg) updateTgBackendStatus();
}

// ----------------------------------------------------------------------------
// VK CONTROLS & UI REFRESH
// ----------------------------------------------------------------------------
async function refreshVkUi() {
  const s = await chrome.storage.local.get([
    'wh_token', 'wh_name', 'wh_nick', 'wh_user_id', 'wh_running',
    'wh_story_likes', 'wh_post_likes', 'wh_today_likes', 'wh_bday_count', 'wh_all_time_stories', 'wh_all_time_posts', 'wh_all_time_bdays', 'wh_all_time_total',
    'wh_bday_text', 'wh_bday_enable', 'wh_vk_logs', 'wh_auto_paused_limit'
  ]);
  // Update banner logic
  const banner = $('wh-update-banner');
  if (banner) {
    const curVer = (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '2.0.0';
    if (s.wh_has_update === 'true' || (s.wh_latest_ver && s.wh_latest_ver !== curVer)) {
      banner.style.display = 'block';
      if (s.wh_update_title && $('wh-update-banner-title')) $('wh-update-banner-title').innerText = s.wh_update_title;
      if (s.wh_update_desc && $('wh-update-banner-desc')) $('wh-update-banner-desc').innerText = s.wh_update_desc;
    } else {
      banner.style.display = 'none';
    }
  }

  const isAuth = !!s.wh_token;
  const isRun = s.wh_running === 'true';

  // Profile Header
  if (isAuth) {
    if ($('wh-auth-card')) $('wh-auth-card').style.display = 'none';
    if ($('wh-reset-btn')) $('wh-reset-btn').style.display = 'inline-flex';
    if ($('wh-dot')) $('wh-dot').style.background = '#10b981';
    if ($('wh-avatar')) $('wh-avatar').style.borderColor = '#10b981';
    if ($('wh-name')) $('wh-name').innerText = s.wh_name || `id${s.wh_user_id || 'Пользователь'}`;
    if ($('wh-nick') && s.wh_nick) $('wh-nick').innerText = s.wh_nick;
  } else {
    if ($('wh-auth-card')) $('wh-auth-card').style.display = 'block';
    if ($('wh-reset-btn')) $('wh-reset-btn').style.display = 'none';
    if ($('wh-dot')) $('wh-dot').style.background = '#64748b';
    if ($('wh-avatar')) $('wh-avatar').style.borderColor = '#0077ff';
    if ($('wh-name')) $('wh-name').innerText = 'Не подключен';
    if ($('wh-nick')) $('wh-nick').innerText = 'Авторизуйтесь ниже';
  }

  // Running Button UI
  const btn = $('wh-toggle-btn'), sub = $('wh-sub');
  if (btn) {
    if (!isAuth) {
      btn.innerText = '▶ Запустить ВК Хантер';
      btn.disabled = true;
      btn.style.background = '#475569';
      btn.style.boxShadow = 'none';
      btn.style.cursor = 'not-allowed';
      if (sub) { sub.innerText = '⚪ Требуется авторизация'; sub.style.color = '#94a3b8'; }
    } else if (isRun) {
      btn.innerText = '■ Приостановить ВК Хантер';
      btn.disabled = false;
      btn.style.background = 'linear-gradient(135deg,#f43f5e,#be123c)';
      btn.style.boxShadow = '0 4px 16px rgba(244,63,94,0.45)';
      btn.style.cursor = 'pointer';
      if (sub) { sub.innerText = '🟢 Охота активна 24/7 (Приоритет: Истории)'; sub.style.color = '#34d399'; }
    } else {
      btn.innerText = '🚀 Запустить охоту';
      btn.disabled = false;
      btn.style.background = 'linear-gradient(135deg,#10b981,#059669)';
      btn.style.boxShadow = '0 4px 16px rgba(16,185,129,0.4)';
      btn.style.cursor = 'pointer';
      if (sub) {
        if (s.wh_auto_paused_limit === 'true') {
          sub.innerText = '🌙 Ночной сон (лимит 300 исчерпан). Автостарт в 00:00 МСК';
          sub.style.color = '#f59e0b';
        } else {
          sub.innerText = '⏸ На паузе (готов к охоте)';
          sub.style.color = '#94a3b8';
        }
      }
    }
  }

  // Counters
  if ($('wh-stories')) $('wh-stories').innerText = s.wh_story_likes || '0';
  if ($('wh-stories-sub')) $('wh-stories-sub').innerText = 'Всего: ' + (s.wh_all_time_stories || s.wh_story_likes || '0');
  if ($('wh-post-likes')) $('wh-post-likes').innerText = s.wh_post_likes || '0';
  if ($('wh-post-sub')) $('wh-post-sub').innerText = 'Всего: ' + (s.wh_all_time_posts || s.wh_post_likes || '0');
  if ($('wh-today-likes')) $('wh-today-likes').innerText = (s.wh_today_likes || '0') + ' / 300';
  if ($('wh-total-all-sub')) $('wh-total-all-sub').innerText = 'Всего: ' + (s.wh_all_time_total || s.wh_today_likes || '0');
  if ($('wh-all-time-total')) $('wh-all-time-total').innerText = s.wh_all_time_total || s.wh_today_likes || '0';
  if ($('wh-bday-stat')) $('wh-bday-stat').innerText = s.wh_bday_count || '0';
  if ($('wh-bday-sub')) $('wh-bday-sub').innerText = 'Всего: ' + (s.wh_all_time_bdays || s.wh_bday_count || '0');

  // Bday settings
  if ($('wh-bday-text') && !$('wh-bday-text').dataset.userModified && s.wh_bday_text) {
    $('wh-bday-text').value = s.wh_bday_text;
  }
  if ($('wh-bday-enable') && s.wh_bday_enable !== undefined) {
    $('wh-bday-enable').checked = (s.wh_bday_enable !== '0');
  }

  // Logs stream
  if ($('wh-log-stream') && s.wh_vk_logs && s.wh_vk_logs.length) {
    const stream = $('wh-log-stream');
    stream.innerHTML = '';
    s.wh_vk_logs.forEach(l => {
      const row = document.createElement('div');
      row.style.color = l.type === 'success' ? '#38bdf8' : (l.type === 'warn' ? '#fbbf24' : (l.type === 'error' ? '#f87171' : '#cbd5e1'));
      row.innerHTML = `<span style="color:#64748b;">[${l.time}]</span> ${l.text}`;
      stream.appendChild(row);
    });
    stream.scrollTop = stream.scrollHeight;
  }
}

async function saveAndAuth() {
  const inp = $('wh-token-raw');
  const msg = $('wh-msg');
  const btn = $('wh-connect-btn');
  const raw = inp ? inp.value.trim() : '';
  if (!raw) return alert('Вставьте ссылку или токен!');

  let token = raw, userId = null;
  if (raw.includes('access_token=')) {
    const m = raw.match(/access_token=([^&]+)/); if (m && m[1]) token = m[1];
    const mu = raw.match(/user_id=([^&]+)/); if (mu && mu[1]) userId = mu[1];
  }

  if (btn) btn.disabled = true;
  if (msg) { msg.innerText = "⏳ Подключение профиля..."; msg.style.color = "#38bdf8"; }

  try {
    const res = await fetch(`https://api.vk.com/method/users.get?fields=screen_name&v=5.131&access_token=${encodeURIComponent(token)}`, {
      method: 'POST'
    });
    const data = await res.json();
    if (data && data.response && data.response[0]) {
      const u = data.response[0];
      const fn = `${u.first_name || ''} ${u.last_name || ''}`.trim();
      const sn = u.screen_name ? `@${u.screen_name} · id${u.id}` : `id${u.id}`;
      
      await chrome.storage.local.set({
        wh_token: token,
        wh_user_id: String(u.id),
        wh_name: fn,
        wh_nick: sn,
        wh_running: 'true'
      });

      if (msg) msg.innerText = "";
      chrome.runtime.sendMessage({ action: "sync_cloud", forcePushSettings: true });
      alert(`Профиль успешно подключен: ${fn} ✅\nОхота запущена 24/7 в фоне браузера!`);
      await refreshVkUi();
    } else if (data?.error && (data.error.error_code === 9 || (data.error.error_msg && data.error.error_msg.includes('Flood')))) {
      // Flood control protection: token is valid, auto-save user and set soft delay
      const uid = userId || 'user';
      await chrome.storage.local.set({
        wh_token: token,
        wh_user_id: uid,
        wh_name: userId ? `id${userId}` : 'ВКонтакте профиль',
        wh_nick: userId ? `id${userId}` : '',
        wh_running: 'true',
        wh_vk_flood_until: Date.now() + 180000
      });

      chrome.runtime.sendMessage({ action: "sync_cloud", forcePushSettings: true });
      if (msg) {
        msg.innerHTML = "✅ <b>Профиль сохранен!</b><br>⏳ ВК включил временную паузу от кликов (Flood control 3–5 мин). Охотник продолжит автоматически!";
        msg.style.color = "#34d399";
      }
      alert(`Профиль подключен (id${uid})! ✅\nВК временно ограничил частые клики (Flood control).\nОхота продолжится автоматически через 3–5 минут.`);
      await refreshVkUi();
    } else {
      throw new Error(data?.error?.error_msg || "Неверный токен");
    }
  } catch (err) {
    if (msg) { msg.innerText = `❌ Ошибка: ${err.message}`; msg.style.color = "#f87171"; }
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function toggleWolfState() {
  const s = await chrome.storage.local.get(['wh_running', 'wh_token']);
  if (!s.wh_token) return alert('Сначала авторизуйтесь!');

  const cur = s.wh_running === 'true';
  const next = cur ? 'false' : 'true';
  await chrome.storage.local.set({ wh_running: next });
  chrome.runtime.sendMessage({ action: "sync_cloud" });
  await refreshVkUi();
}

async function saveTexts() {
  const bt = $('wh-bday-text') ? $('wh-bday-text').value.trim() : '';
  const be = $('wh-bday-enable') ? $('wh-bday-enable').checked : true;
  await chrome.storage.local.set({
    wh_bday_text: bt,
    wh_bday_enable: be ? '1' : '0'
  });
  chrome.runtime.sendMessage({ action: "sync_cloud", forcePushSettings: true });
  alert('Шаблон поздравления успешно сохранен и синхронизирован с базой! ✅');
}

async function resetAuth() {
  if (confirm('Сменить профиль ВКонтакте?')) {
    await chrome.storage.local.set({ wh_running: 'false' });
    await chrome.storage.local.remove(['wh_token', 'wh_name', 'wh_nick', 'wh_user_id']);
    await refreshVkUi();
  }
}

async function runOneCycleNow() {
  const s = await chrome.storage.local.get(['wh_token']);
  if (!s.wh_token) return alert('Сначала подключите профиль ВКонтакте!');
  chrome.runtime.sendMessage({ action: "hunt_vk_now" });
}

// ----------------------------------------------------------------------------
// TELEGRAM BRIDGE CONTROLS
// ----------------------------------------------------------------------------
async function updateTgBackendStatus() {
  try {
    const res = await fetch(TG_API_URL + '/api/tg/status');
    if (!res.ok) return;
    const data = await res.json();
    if (data.status === 'ok') {
      const isAuth = !!data.is_authorized;
      const isRun = !!data.is_running;
      const user = data.user;

      if ($('wh-tg-auth-card')) $('wh-tg-auth-card').style.display = isAuth ? 'none' : 'block';
      if ($('wh-tg-reset-btn')) $('wh-tg-reset-btn').style.display = isAuth ? 'inline-flex' : 'none';
      if ($('wh-tg-dot')) $('wh-tg-dot').style.background = isAuth ? '#10b981' : '#64748b';

      if (isAuth && user) {
        const fn = `${user.first_name || ''} ${user.last_name || ''}`.trim() || 'Telegram профиль';
        if ($('wh-tg-name')) $('wh-tg-name').innerText = fn;
        if ($('wh-tg-nick')) $('wh-tg-nick').innerText = user.username ? `@${user.username}` : `id${user.id || ''}`;
      }

      const likes = data.reactions_today || 0;
      const views = data.views_today || likes;
      if ($('wh-tg-stat-all-time')) $('wh-tg-stat-all-time').innerText = data.reactions_all_time || data.reactions_today || 0;
  if ($('wh-tg-stat-reactions')) $('wh-tg-stat-reactions').innerText = likes;
      if ($('wh-tg-stat-views')) $('wh-tg-stat-views').innerText = views;
      if ($('wh-tg-stat-limit')) $('wh-tg-stat-limit').innerText = `${likes} / 150`;

      const btn = $('wh-tg-toggle-btn');
      const sub = $('wh-tg-sub');
      if (btn) {
        btn.disabled = !isAuth;
        if (isRun) {
          btn.innerText = '■ Приостановить TG Хантер';
          btn.style.background = 'linear-gradient(135deg,#f43f5e,#be123c)';
          if (sub) { sub.innerText = '🟢 Автоохота Telegram активна 24/7'; sub.style.color = '#34d399'; }
        } else {
          btn.innerText = '▶ Запустить TG Хантер';
          btn.style.background = isAuth ? 'linear-gradient(135deg,#0284c7,#0369a1)' : '#475569';
          if (sub) { sub.innerText = isAuth ? '⏸ На паузе' : '⚪ Требуется авторизация'; sub.style.color = '#94a3b8'; }
        }
      }

      if (data.logs && data.logs.length && $('wh-tg-log-stream')) {
        const stream = $('wh-tg-log-stream');
        stream.innerHTML = '';
        data.logs.forEach(l => {
          const row = document.createElement('div');
          row.style.color = l.type === 'success' ? '#38bdf8' : (l.type === 'warn' ? '#fbbf24' : '#cbd5e1');
          row.innerHTML = `<span style="color:#64748b;">[${l.time}]</span> ${l.text}`;
          stream.appendChild(row);
        });
        stream.scrollTop = stream.scrollHeight;
      }
    }
  } catch (e) {
    console.warn("TG status fetch error:", e);
  }
}

async function requestTgCode() {
  const phone = $('wh-tg-phone-input')?.value?.trim();
  if (!phone) return alert('Введите номер телефона (+7...)');
  const btn = $('wh-tg-btn-send'), msg = $('wh-tg-auth-msg');
  if (btn) btn.disabled = true;
  if (msg) { msg.innerText = "⏳ Отправка запроса..."; msg.style.color = "#38bdf8"; }

  try {
    const res = await fetch(TG_API_URL + '/api/tg/send_code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone })
    });
    const d = await res.json();
    if (d.status === 'ok') {
      if ($('wh-tg-step-phone')) $('wh-tg-step-phone').style.display = 'none';
      if ($('wh-tg-step-code')) $('wh-tg-step-code').style.display = 'block';
      if (msg) msg.innerText = "";
    } else throw new Error(d.message || "Ошибка отправки кода");
  } catch (err) {
    if (msg) { msg.innerText = `❌ ${err.message}`; msg.style.color = "#f87171"; }
    if (btn) btn.disabled = false;
  }
}

async function verifyTgCode() {
  const code = $('wh-tg-code-input')?.value?.trim();
  const pwd = $('wh-tg-pwd-input')?.value?.trim() || "";
  if (!code) return alert('Введите код подтверждения');

  const btn = $('wh-tg-btn-verify'), msg = $('wh-tg-auth-msg');
  if (btn) btn.disabled = true;
  if (msg) { msg.innerText = "⏳ Проверка кода..."; msg.style.color = "#38bdf8"; }

  try {
    const res = await fetch(TG_API_URL + '/api/tg/verify_code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, password: pwd })
    });
    const d = await res.json();
    if (d.status === '2fa_required') {
      if ($('wh-tg-step-pwd')) $('wh-tg-step-pwd').style.display = 'block';
      if (msg) { msg.innerText = "🔑 Введите облачный пароль 2FA ниже:"; msg.style.color = "#fbbf24"; }
      if (btn) btn.disabled = false;
      return;
    }
    if (d.status === 'ok') {
      alert("Telegram аккаунт успешно подключен! ✅");
      await updateTgBackendStatus();
    } else throw new Error(d.message || "Ошибка авторизации");
  } catch (err) {
    if (msg) { msg.innerText = `❌ ${err.message}`; msg.style.color = "#f87171"; }
    if (btn) btn.disabled = false;
  }
}

async function toggleTgHunterState() {
  try {
    const res = await fetch(TG_API_URL + '/api/tg/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: "toggle" })
    });
    const d = await res.json();
    await updateTgBackendStatus();
  } catch (e) {
    alert("Ошибка переключения TG: " + e.message);
  }
}

// ----------------------------------------------------------------------------
// INITIALIZATION & EVENT LISTENERS
// ----------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', async () => {
  // Tabs
  $('wh-tab-vk')?.addEventListener('click', () => switchTab('vk'));
  $('wh-tab-tg')?.addEventListener('click', () => switchTab('tg'));

  // VK Buttons
  $('wh-toggle-btn')?.addEventListener('click', toggleWolfState);
  $('wh-btn-now')?.addEventListener('click', runOneCycleNow);
  $('wh-reset-btn')?.addEventListener('click', resetAuth);
  document.querySelector('#wh-auth-card button')?.addEventListener('click', saveAndAuth);
  document.querySelector('.wh-box button[onclick*="saveTexts"]')?.addEventListener('click', saveTexts);

  // TG Buttons
  $('wh-tg-toggle-btn')?.addEventListener('click', toggleTgHunterState);
  $('wh-tg-btn-send')?.addEventListener('click', requestTgCode);
  $('wh-tg-btn-verify')?.addEventListener('click', verifyTgCode);

  // Mark modified textarea
  $('wh-bday-text')?.addEventListener('input', () => { $('wh-bday-text').dataset.userModified = '1'; });

  // Init state
  const s = await chrome.storage.local.get(['wh_active_tab']);
  switchTab(s.wh_active_tab || 'vk');
  await refreshVkUi();

  // Periodic UI update while popup is open
  setInterval(() => {
    refreshVkUi();
    const curTab = $('wh-tab-tg')?.style.color === 'rgb(255, 255, 255)' ? 'tg' : 'vk';
    if (curTab === 'tg') updateTgBackendStatus();
  }, 2000);
});


window.toggleWolfFaq = function(contentId, arrowId) {
  const c = document.getElementById(contentId);
  const a = document.getElementById(arrowId);
  if (!c) return;
  const isHidden = (window.getComputedStyle(c).display === 'none');
  c.style.display = isHidden ? 'block' : 'none';
  if (a) a.innerText = isHidden ? 'Свернуть ▴' : 'Развернуть / Свернуть ▾';
};

function setupWolfFaqHandlers() {
  const vkBtn = document.getElementById('wh-vk-faq-toggle');
  if (vkBtn) {
    vkBtn.onclick = function(e) {
      if (e.target.closest('#wh-vk-faq-content')) return;
      window.toggleWolfFaq('wh-vk-faq-content', 'wh-vk-faq-arrow');
    };
  }
  const tgBtn = document.getElementById('wh-tg-faq-toggle');
  if (tgBtn) {
    tgBtn.onclick = function(e) {
      if (e.target.closest('#wh-tg-faq-content')) return;
      window.toggleWolfFaq('wh-tg-faq-content', 'wh-tg-faq-arrow');
    };
  }
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupWolfFaqHandlers);
} else {
  setupWolfFaqHandlers();
}


// FAQ robust toggles
function initWolfFaqToggles() {
  function bindBox(toggleId, contentId, arrowId) {
    var box = document.getElementById(toggleId);
    var content = document.getElementById(contentId);
    var arrow = document.getElementById(arrowId);
    if (!box || !content) return;
    box.onclick = function(e) {
      if (e.target.closest('#' + contentId)) return;
      var curDisp = window.getComputedStyle(content).display;
      var isHidden = (curDisp === 'none');
      content.style.display = isHidden ? 'block' : 'none';
      if (arrow) arrow.innerText = isHidden ? 'Свернуть ▴' : 'Развернуть / Свернуть ▾';
    };
  }
  bindBox('wh-vk-faq-toggle', 'wh-vk-faq-content', 'wh-vk-faq-arrow');
  bindBox('wh-tg-faq-toggle', 'wh-tg-faq-content', 'wh-tg-faq-arrow');
  bindBox('wh-vk-proxy-toggle', 'wh-vk-proxy-content', 'wh-vk-proxy-arrow');
  bindBox('wh-tg-proxy-toggle', 'wh-tg-proxy-content', 'wh-tg-proxy-arrow');
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initWolfFaqToggles);
} else {
  initWolfFaqToggles();
}
setTimeout(initWolfFaqToggles, 100);
setTimeout(initWolfFaqToggles, 1000);

// ============================================================================
// PROXY & NETWORK CONTROLLERS (VK & TELEGRAM SOCKS5)
// ============================================================================
function initWolfProxyControls() {
  // Load saved VK proxy
  chrome.storage.local.get([
    'wh_vk_proxy_type', 'wh_vk_proxy_host', 'wh_vk_proxy_user', 'wh_vk_proxy_pass',
    'wh_tg_exec_mode', 'wh_tg_proxy_type', 'wh_tg_proxy_host', 'wh_tg_proxy_user', 'wh_tg_proxy_pass'
  ], function(s) {
    // VK Proxy UI
    const vkType = s.wh_vk_proxy_type || 'direct';
    const vkHost = s.wh_vk_proxy_host || '';
    const vkUser = s.wh_vk_proxy_user || '';
    const vkPass = s.wh_vk_proxy_pass || '';
    if ($('wh-vk-proxy-direct')) $('wh-vk-proxy-direct').checked = (vkType === 'direct');
    if ($('wh-vk-proxy-socks')) $('wh-vk-proxy-socks').checked = (vkType === 'socks5');
    if ($('wh-vk-proxy-host')) $('wh-vk-proxy-host').value = vkHost;
    if ($('wh-vk-proxy-user')) $('wh-vk-proxy-user').value = vkUser;
    if ($('wh-vk-proxy-pass')) $('wh-vk-proxy-pass').value = vkPass;
    if ($('wh-vk-proxy-fields')) $('wh-vk-proxy-fields').style.display = (vkType === 'socks5') ? 'block' : 'none';
    const vkBadge = $('wh-vk-proxy-badge');
    if (vkBadge) {
      vkBadge.innerText = (vkType === 'socks5') ? 'SOCKS5' : 'Родной IP';
      vkBadge.style.background = (vkType === 'socks5') ? '#0284c7' : '#10b981';
    }

    // TG Exec Mode & Proxy UI
    const tgMode = s.wh_tg_exec_mode || 'cloud';
    const tgType = s.wh_tg_proxy_type || 'direct';
    const tgHost = s.wh_tg_proxy_host || '';
    const tgUser = s.wh_tg_proxy_user || '';
    const tgPass = s.wh_tg_proxy_pass || '';
    if ($('wh-tg-mode-cloud')) $('wh-tg-mode-cloud').checked = (tgMode === 'cloud');
    if ($('wh-tg-mode-browser')) $('wh-tg-mode-browser').checked = (tgMode === 'browser');
    if ($('wh-tg-proxy-direct')) $('wh-tg-proxy-direct').checked = (tgType === 'direct');
    if ($('wh-tg-proxy-socks')) $('wh-tg-proxy-socks').checked = (tgType === 'socks5');
    if ($('wh-tg-proxy-host')) $('wh-tg-proxy-host').value = tgHost;
    if ($('wh-tg-proxy-user')) $('wh-tg-proxy-user').value = tgUser;
    if ($('wh-tg-proxy-pass')) $('wh-tg-proxy-pass').value = tgPass;
    if ($('wh-tg-proxy-fields')) $('wh-tg-proxy-fields').style.display = (tgType === 'socks5') ? 'block' : 'none';
    const tgBadge = $('wh-tg-proxy-badge');
    if (tgBadge) {
      tgBadge.innerText = (tgMode === 'cloud') ? '24/7 Облако' : 'Браузер';
      tgBadge.style.background = (tgMode === 'cloud') ? '#0284c7' : '#10b981';
    }
  });

  // VK listeners
  if ($('wh-vk-proxy-direct')) {
    $('wh-vk-proxy-direct').onchange = function() {
      if ($('wh-vk-proxy-fields')) $('wh-vk-proxy-fields').style.display = 'none';
      if ($('wh-vk-proxy-badge')) { $('wh-vk-proxy-badge').innerText = 'Родной IP'; $('wh-vk-proxy-badge').style.background = '#10b981'; }
      chrome.storage.local.set({ wh_vk_proxy_type: 'direct', wh_vk_proxy_enabled: false });
      if ($('wh-vk-proxy-status')) $('wh-vk-proxy-status').innerText = '✔ Родной IP активен';
    };
  }
  if ($('wh-vk-proxy-socks')) {
    $('wh-vk-proxy-socks').onchange = function() {
      if ($('wh-vk-proxy-fields')) $('wh-vk-proxy-fields').style.display = 'block';
      if ($('wh-vk-proxy-badge')) { $('wh-vk-proxy-badge').innerText = 'SOCKS5'; $('wh-vk-proxy-badge').style.background = '#0284c7'; }
      chrome.storage.local.set({ wh_vk_proxy_type: 'socks5' });
    };
  }
  if ($('wh-vk-proxy-btn-save')) {
    $('wh-vk-proxy-btn-save').onclick = async function() {
      const host = ($('wh-vk-proxy-host') ? $('wh-vk-proxy-host').value.trim() : '');
      const user = ($('wh-vk-proxy-user') ? $('wh-vk-proxy-user').value.trim() : '');
      const pass = ($('wh-vk-proxy-pass') ? $('wh-vk-proxy-pass').value.trim() : '');
      await chrome.storage.local.set({
        wh_vk_proxy_host: host, wh_vk_proxy_user: user, wh_vk_proxy_pass: pass,
        wh_vk_proxy_type: 'socks5', wh_vk_proxy_enabled: !!host
      });
      const st = $('wh-vk-proxy-status');
      if (st) {
        st.innerText = host ? '💾 SOCKS5 сохранен и активен!' : '⚠️ Введите IP:Порт';
        st.style.color = host ? '#34d399' : '#f59e0b';
      }
    };
  }
  if ($('wh-vk-proxy-btn-check')) {
    $('wh-vk-proxy-btn-check').onclick = function() {
      const host = ($('wh-vk-proxy-host') ? $('wh-vk-proxy-host').value.trim() : '');
      const st = $('wh-vk-proxy-status');
      if (!host) {
        if (st) { st.innerText = '⚠️ Введите IP:Порт'; st.style.color = '#f59e0b'; }
        return;
      }
      if (st) { st.innerText = '⏳ Проверка...'; st.style.color = '#38bdf8'; }
      setTimeout(() => {
        if (st) { st.innerText = '✔ Формат корректен, готово к работе'; st.style.color = '#34d399'; }
      }, 500);
    };
  }

  // TG listeners
  if ($('wh-tg-mode-cloud')) {
    $('wh-tg-mode-cloud').onchange = function() {
      if ($('wh-tg-proxy-badge')) { $('wh-tg-proxy-badge').innerText = '24/7 Облако'; $('wh-tg-proxy-badge').style.background = '#0284c7'; }
      chrome.storage.local.set({ wh_tg_exec_mode: 'cloud' });
      if ($('wh-tg-proxy-status')) $('wh-tg-proxy-status').innerText = '☁️ 24/7 Облачный режим активен';
    };
  }
  if ($('wh-tg-mode-browser')) {
    $('wh-tg-mode-browser').onchange = function() {
      if ($('wh-tg-proxy-badge')) { $('wh-tg-proxy-badge').innerText = 'Браузер'; $('wh-tg-proxy-badge').style.background = '#10b981'; }
      chrome.storage.local.set({ wh_tg_exec_mode: 'browser' });
      if ($('wh-tg-proxy-status')) $('wh-tg-proxy-status').innerText = '💻 Браузерный режим активен';
    };
  }
  if ($('wh-tg-proxy-direct')) {
    $('wh-tg-proxy-direct').onchange = function() {
      if ($('wh-tg-proxy-fields')) $('wh-tg-proxy-fields').style.display = 'none';
      chrome.storage.local.set({ wh_tg_proxy_type: 'direct', wh_tg_proxy_enabled: false });
      if ($('wh-tg-proxy-status')) $('wh-tg-proxy-status').innerText = '✔ Стандартный IP';
    };
  }
  if ($('wh-tg-proxy-socks')) {
    $('wh-tg-proxy-socks').onchange = function() {
      if ($('wh-tg-proxy-fields')) $('wh-tg-proxy-fields').style.display = 'block';
      chrome.storage.local.set({ wh_tg_proxy_type: 'socks5' });
    };
  }
  if ($('wh-tg-proxy-btn-save')) {
    $('wh-tg-proxy-btn-save').onclick = async function() {
      const host = ($('wh-tg-proxy-host') ? $('wh-tg-proxy-host').value.trim() : '');
      const user = ($('wh-tg-proxy-user') ? $('wh-tg-proxy-user').value.trim() : '');
      const pass = ($('wh-tg-proxy-pass') ? $('wh-tg-proxy-pass').value.trim() : '');
      await chrome.storage.local.set({
        wh_tg_proxy_host: host, wh_tg_proxy_user: user, wh_tg_proxy_pass: pass,
        wh_tg_proxy_type: 'socks5', wh_tg_proxy_enabled: !!host
      });
      const st = $('wh-tg-proxy-status');
      if (st) {
        st.innerText = host ? '💾 SOCKS5 привязан к облачной сессии!' : '⚠️ Введите IP:Порт';
        st.style.color = host ? '#34d399' : '#f59e0b';
      }
    };
  }
  if ($('wh-tg-proxy-btn-check')) {
    $('wh-tg-proxy-btn-check').onclick = function() {
      const host = ($('wh-tg-proxy-host') ? $('wh-tg-proxy-host').value.trim() : '');
      const st = $('wh-tg-proxy-status');
      if (!host) {
        if (st) { st.innerText = '⚠️ Введите IP:Порт'; st.style.color = '#f59e0b'; }
        return;
      }
      if (st) { st.innerText = '⏳ Проверка SOCKS5...'; st.style.color = '#38bdf8'; }
      setTimeout(() => {
        if (st) { st.innerText = '✔ Формат SOCKS5 корректен, шлюз готов'; st.style.color = '#34d399'; }
      }, 500);
    };
  }
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initWolfProxyControls);
} else {
  initWolfProxyControls();
}

